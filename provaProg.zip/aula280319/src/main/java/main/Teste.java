package main;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Teste {

	public static void main(String[] args) {
		EntityManagerFactory enf = Persistence.createEntityManagerFactory("MinhaPersistencia");

		enf.createEntityManager();
	}

}
